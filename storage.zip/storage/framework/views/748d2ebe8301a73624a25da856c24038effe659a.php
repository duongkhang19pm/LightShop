

<?php $__env->startSection('content'); ?>

<div class="main-content container-fluid">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
                <h3>Chất Liệu</h3>
                
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class='breadcrumb-header'>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Chất Liệu</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <section class="section" >
        <div class="card">
            <div class="card-header">
                Danh Sách
            </div>
            <div class="card-body "id="table-hover-row">
                <a href="<?php echo e(route('admin.chatlieu.them')); ?>" class="btn btn-info mb-2" ><i class="fas fa-plus"></i> Thêm mới</a>
                <table class='table  table-hover' id="table1">
                    <thead>
                        <tr>
                            <th width="5%">#</th>
                             <th width="20%">Tên chất liệu</th>
                             <th width="20%">Tên chất liệu không dấu</th>
                             <th width="5%">Sửa</th>
                             <th width="5%">Xóa</th>
                        </tr>
                    </thead>
                    <tbody >
                         <?php $__currentLoopData = $chatlieu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tr>
                                 <td><?php echo e($loop->iteration); ?></td>
                                 <td><?php echo e($value->tenchatlieu); ?></td>
                                 <td><?php echo e($value->tenchatlieu_slug); ?></td>
                                 <td class="align-middle text-right">
                              <a href="<?php echo e(route('admin.chatlieu.sua', ['id' => $value->id])); ?>" class="btn btn-sm btn-secondary">
                                <i class="fa fa-pencil-alt"></i>
                                <span class="sr-only">Edit</span>
                              </a>
                          </td>
                          <td>
                              <a href="<?php echo e(route('admin.chatlieu.xoa', ['id' => $value->id])); ?>" class="btn btn-sm btn-secondary">
                                <i class="far fa-trash-alt"></i>
                                <span class="sr-only">Remove</span>
                              </a>
                            </td>
                             </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
            </div>
        </div>

    </section>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wamp\www\LightShop\resources\views/admin/chatlieu/danhsach.blade.php ENDPATH**/ ?>