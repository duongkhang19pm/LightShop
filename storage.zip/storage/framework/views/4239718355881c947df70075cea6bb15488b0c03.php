<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title><?php echo e(config('app.name', 'Laravel')); ?></title>
      <link rel="stylesheet" href="<?php echo e(asset('public/backend/css/bootstrap.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('public/backend/css/app.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('public/images/logo.png')); ?>" type="image/x-icon">
</head>

<body>
<div id="auth">

    <div class="container">
        <div class="row">
            <div class="col-md-5 col-sm-12 mx-auto">
                <div class="card pt-4">
                    <div class="card-body">
                        <div class="text-center mb-5">
                            <img src="<?php echo e(asset('public/images/logo.png')); ?>" height="50" class='mb-4'>
                            <h3>Đăng Nhập</h3>
                            
                        </div>
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                            <div class="form-group position-relative has-icon-left">
                                <label for="email">Tài Khoản</label>
                                <div class="position-relative">
                                     

                                    <input type="text" class="form-control form-control-lg<?php echo e(($errors->has('email') || $errors->has('username')) ? ' is-invalid' : ''); ?>" id="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email hoặc Tên đăng nhập" required />

                                    <?php if($errors->has('email') || $errors->has('username')): ?>
                                      <span class="invalid-feedback">
                                          <strong><i class="fa fa-exclamation-circle fa-fw"></i> 
                                          <?php echo e(empty($errors->first('email')) ? $errors->first('username') : $errors->first('email')); ?>

                                        </strong>
                                      </span>
                                    <?php endif; ?>
                                </div>

                                

                            </div>
                            <div class="form-group position-relative has-icon-left">
                                <div class="clearfix">
                                    <label for="password">Mật Khẩu</label>
                                   

                                    <?php if(Route::has('password.request')): ?>
                                        <a class="float-end" href="<?php echo e(route('password.request')); ?>">
                                            <small>Quên mật khẩu đăng nhập?</small>
                                        </a>
                                    <?php endif; ?>
                                </div>
                                <div class="position-relative">
                                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                                    <div class="form-control-icon">
                                        <i data-feather="lock"></i>
                                    </div>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                              
                            </div>

                            <div class='form-check clearfix my-4'>
                                <div class="checkbox float-start">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                    <label for="checkbox1">Duy trì đăng nhập</label>
                                </div>
                                <div class="float-end">
                                    <a href="<?php echo e(route('register')); ?>">Tạo tài khoản mới ?</a>
                                </div>
                            </div>
                            <div class="clearfix">
                                <button class="btn btn-dark float-end">Đăng Nhập</button>
                            </div>
                        </form>
                        <div class="divider">
                            <div class="divider-text">OR</div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <button class="btn btn-block mb-2 btn-primary"><i data-feather="facebook"></i>
                                    Facebook</button>
                            </div>
                            <div class="col-sm-6">
                                <button class="btn btn-block mb-2 btn-danger"><i data-feather="mail"></i>
                                    Gmail</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
    <script src="<?php echo e(asset('public/backend/js/feather-icons/feather.min.js')); ?>"></script>
     <script src="<?php echo e(asset('public/backend/js/app.js')); ?>"></script>

    <script src="<?php echo e(asset('public/backend/js/main.js')); ?>"></script>
</body>

</html>




<?php /**PATH D:\Wamp\www\LightShop\resources\views/auth/login.blade.php ENDPATH**/ ?>