

<?php $__env->startSection('pagetitle'); ?>
    Quản trị hệ thống
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page">
        <div class="page-inner">
            <header class="page-title-bar">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item active">
                            <a href="<?php echo e(route('admin.home')); ?>"><i class="breadcrumb-icon fa fa-angle-left mr-2"></i>Trang chủ</a>
                        </li>
                    </ol>
                </nav>
                <h1 class="page-title">Trang Nhân Viên</h1>
            </header>
            <div class="page-section">
                <h3>Trang chủ Nhân Viên đang cập nhật!</h3>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nhanvien', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wamp\www\LightShop\resources\views/nhanvien/index.blade.php ENDPATH**/ ?>