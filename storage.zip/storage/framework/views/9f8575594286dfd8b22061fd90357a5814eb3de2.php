

<?php $__env->startSection('content'); ?>

<div class="main-content container-fluid">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
                <h3>Sản Phẩm</h3>
                
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class='breadcrumb-header'>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('nhanvien.home')); ?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Sản Phẩm</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <section class="section" >
        <div class="card">
            <div class="card-header">
                Danh Sách
            </div>
            <div class="card-body "id="table-hover-row">
                <a href="<?php echo e(route('nhanvien.sanpham.them')); ?>" class="btn btn-info mb-2" ><i class="fas fa-plus"></i> Thêm mới</a>
                <a href="#nhap" class="btn btn-danger mb-2" data-bs-toggle="modal" data-bs-target="#importModal"><i class="fas fa-upload"></i> Nhập từ Excel</a>
                <a href="<?php echo e(route('nhanvien.sanpham.xuat')); ?>" class="btn btn-success mb-2"><i class="fas fa-download"></i> Xuất ra Excel</a>
                <table class='table  table-hover' id="table1">
                    <thead>
                             <tr>
                                 <th width="5%">#</th>
                                 <th width="15%">Hình ảnh</th>
                                 
                                 <th width="30%">Thông Tin Sản Phẩm</th>
                                 <th width="25%">Tên sản phẩm không dấu</th>           
                                 <th width="15%">Số Lượng</th>
                                 <th width="5%">Sửa</th>
                                 <th width="5%">Xóa</th>
                             </tr>
                    </thead>
                    <tbody>
                         <?php $__currentLoopData = $sanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tr>
                                <td><?php echo e($sanpham->firstItem() + $loop->index); ?></td>
                                
                                 <td class="text-center">
                                  
                                    <?php if(($value->hinhanh)->isEmpty()): ?>
                                        <img src="<?php echo e(env('APP_URL').'/public/images/noimage.png'); ?>" height="70" width="100"/>
                                           
                                    <?php else: ?>
                                         <?php $__currentLoopData = $value->hinhanh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 
                                                <img src="<?php echo e($hinhanh_first[$image->id]); ?>" height="70" width="100"/>
                                                 
                                                 <?php break; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                  
                                </td>
                                <td>
                                    Nhóm Sản Phẩm: <?php echo e($value->NhomSanPham->tennhom); ?><br/>
                                    Loại Sản Phẩm: <?php echo e($value->LoaiSanPham->tenloai); ?><br/>
                                    Thương Hiệu: <?php echo e($value->ThuongHieu->tenthuonghieu); ?><br/>
                                    Xuất Xứ: <?php echo e($value->XuatXu->tenxuatxu); ?><br/>
                                    Chất Liệu: <?php echo e($value->ChatLieu->tenchatlieu); ?><br/>
                                    Tên Sản Phẩm :<?php echo e($value->tensanpham); ?><br/>
                                    Đơn Giá :<?php echo e(number_format($value->dongia)); ?> VNĐ<br/>
                                </td>
                                <td><?php echo e($value->tensanpham_slug); ?></td>
                                <td  class="text-end"><?php echo e($value->soluong); ?></td>
                                <td class="align-middle text-right">
                              <a href="<?php echo e(route('nhanvien.sanpham.sua', ['id' => $value->id])); ?>" class="btn btn-sm btn-secondary">
                                <i class="fa fa-pencil-alt"></i>
                                <span class="sr-only">Edit</span>
                              </a>
                          </td>
                          <td>
                              <a href="<?php echo e(route('nhanvien.sanpham.xoa', ['id' => $value->id])); ?>" class="btn btn-sm btn-secondary">
                                <i class="far fa-trash-alt"></i>
                                <span class="sr-only">Remove</span>
                              </a>
                            </td>
                             </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
                </div>
                      <ul class="pagination justify-content-center mt-4">
                       <?php echo e($sanpham->links()); ?>

                     </ul>
                  </div>
                
            </div>
        </div>

    </section>
</div>
<form action="<?php echo e(route('nhanvien.sanpham.nhap')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="importModal" tabindex="-1" role="dialog" aria-labelledby="importModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="importModalLabel">Nhập từ Excel</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-0">
                            <label for="file_excel" class="form-label">Chọn tập tin Excel</label>
                            <input type="file" class="form-control" id="file_excel" name="file_excel" required />
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="fas fa-times"></i> Hủy bỏ</button>
                        <button type="submit" class="btn btn-danger"><i class="fas fa-upload"></i> Nhập dữ liệu</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nhanvien', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wamp\www\LightShop\resources\views/nhanvien/sanpham/danhsach.blade.php ENDPATH**/ ?>